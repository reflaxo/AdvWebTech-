/* 1.2 - Create a New Path document*/

/*Task 3.1 -  require the controller to connect it to the root file*/


/* Task 1.2 - Render the Index route from here*/


/*Task 1.3 & 1.4 & 1.5- 3 define a view - 4 control it from here - 5 control it from the controller
  router.get('/simpleTask', function(req, res, next) {
    res.render('simple_task', { task: 'Washing dishes', effort:"30 minutes", deadline:"today"});
  });*/
  
/*Task 3.2 - Create the routes to the functions you find in the controller*/


/* 1.2 - Create a New Path document (dont forget the export!)*/